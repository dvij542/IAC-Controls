import frictionmap.src
