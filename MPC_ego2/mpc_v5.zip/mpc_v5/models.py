from casadi import *
import params as p
x=SX.sym('x')
y=SX.sym('y')
theta=SX.sym('theta')
v=SX.sym('v')
a=SX.sym('a')
states=vertcat(x,y,theta,v)
c=SX.sym('c')
delta=SX.sym('delta')
controls=vertcat(c,delta)


R1=SX([[0,0],  # Weights for magnitude of speed and steering angles
    [0,10]])
R2=SX([[0,0],   # Weights for rate of change of speed and steering angle
    [0,0]])
rhs=[
        (v)*cos(theta+((atan(tan(delta/9.9)))/2)),
        (v)*sin(theta+((atan(tan(delta/9.9)))/2)),
        (v)*sin(atan(tan(delta/9.9)))/p.L,
        ((c>0)*((v>=0)*(v<p.gear_change_speeds[0])*c*p.gear_throttles[0]+(v>=p.gear_change_speeds[0])*(v<p.gear_change_speeds[1])*c*p.gear_throttles[1]+(v>=p.gear_change_speeds[1])*(v<p.gear_change_speeds[2])*c*p.gear_throttles[2]+(v>=p.gear_change_speeds[2])*(v<p.gear_change_speeds[3])*c*p.gear_throttles[3]+(v>=p.gear_change_speeds[3])*(v<p.gear_change_speeds[4])*c*p.gear_throttles[4]+(v>=p.gear_change_speeds[4])*c*p.gear_throttles[5])-p.air_resistance_const*v*v+(c<0)*c)/p.mass
        # (c>=0)*calc_torque_from_gear_speed(car_speed_to_gear_speed(v),c)/(mass*get_gear_radii(v)) + (c<0)*c
    ]
rhs=vertcat(*rhs)
f=Function('f',[states,controls],[rhs])
n_states=4
n_controls=2
U=SX.sym('U',n_controls,p.N)
P=SX.sym('P',9+4*p.max_no_of_vehicles+8)
X=SX.sym('X',n_states,(p.N+1))
g=SX.sym('g',2,p.N+2)
X[:-1,0]=0
X[-1,0]=P[7]         
itr = SX.sym('I',p.no_iters,p.N)
itr_l = SX.sym('Il',p.no_iters,p.N)
itr_r = SX.sym('Ir',p.no_iters,p.N)
pen = SX.sym('p',2,p.N)
F_dash = SX.sym('Fd',p.no_iters,p.N)
F_val = SX.sym('Fv',p.no_iters,p.N)
F_dash_l = SX.sym('Fdl',p.no_iters,p.N)
F_val_l = SX.sym('Fvl',p.no_iters,p.N)
F_dash_r = SX.sym('Fdr',p.no_iters,p.N)
F_val_r = SX.sym('Fvr',p.no_iters,p.N)
other_vehicle_x = SX.sym('ovx',p.max_no_of_vehicles,p.N+1)
other_vehicle_y = SX.sym('ovy',p.max_no_of_vehicles,p.N+1)
other_vehicle_v = SX.sym('ovv',p.max_no_of_vehicles,p.N+1)
other_vehicle_t = SX.sym('ovt',p.max_no_of_vehicles,p.N+1)
R = SX.sym('R',1,1)

for k in range(0,p.N,1):
    st=X[:,k]
    con=U[:,k]
    f_value=f(st,con)
    st_next=st+(p.T*f_value)
    X[:,k+1]=st_next

g[0,p.N] = X[0,0]
g[1,p.N] = X[1,0]
g[0,p.N+1] = X[2,0]
g[1,p.N+1] = X[3,0]
ff=Function('ff',[U,P],[X])
obj=64000