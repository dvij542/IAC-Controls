import models as m
import params as p
import util_funcs as u
import math
import numpy as np
from casadi import *


################# m.P ###########
# Initial posx,posy and heading angle are 0
# 0 : No of vehicles
# 1,2,3,4,5,6 : Vi, Vf, C0, C1, C2 and C3 for cubic equation of reference line
# 7,8 : Intial speed and steering angle
# (9,10,11,12), (13,14,15,16) ...... (9+4k,10+4k,11+4k,12+4k) : (x,y,velx,vely) for all the surrounding vehicles
# (-8,-7,-6,-5) : Left lane boundary C0, C1, C2, C3
# (-4,-3,-2,-1) : Right lane boundary C0, C1, C2, C3

for t in range(p.max_no_of_vehicles) : 
    m.other_vehicle_x[t,0] = m.P[9+4*t]
    m.other_vehicle_y[t,0] = m.P[10+4*t]
    m.other_vehicle_v[t,0] = (m.P[11+4*t]**2 + m.P[12+4*t]**2+0.01)**0.5
    m.other_vehicle_t[t,0] = math.atan(m.P[12+4*t]/(m.P[11+4*t]+0.1))

Vi = m.P[1]
Vf = m.P[2]
for k in range(0,p.N,1):
    st=m.X[:,k]
    con=m.U[:,k]
    
    m.itr[0,k]=st[0]
    for i in range(1,p.no_iters,1):
        m.F_dash[i,k] = m.P[4]+2*m.P[5]*m.itr[i-1,k]+3*m.P[6]*m.itr[i-1,k]**2
        m.F_val[i,k] = m.P[3] + m.P[4]*m.itr[i-1,k] + m.P[5]*m.itr[i-1,k]**2 + m.P[6]*m.itr[i-1,k]**3
        m.itr[i,k] = m.itr[i-1,k]*((m.F_dash[i,k]**2)/(1+m.F_dash[i,k]**2))+(st[0]+m.F_dash[i,k]*(st[1]-m.F_val[i,k]))/(1+m.F_dash[i,k]**2)
    m.F_dash[0,k] = m.P[4]+2*m.P[5]*m.itr[p.no_iters-1,k]+3*m.P[6]*m.itr[p.no_iters-1,k]**2
    m.F_val[0,k] = m.P[3] + m.P[4]*m.itr[p.no_iters-1,k] + m.P[5]*m.itr[p.no_iters-1,k]**2 + m.P[6]*m.itr[p.no_iters-1,k]**3
    
    m.itr_l[0,k]=st[0]
    for i in range(1,p.no_iters,1):
        m.F_dash_l[i,k] = m.P[-7]+2*m.P[-6]*m.itr_l[i-1,k]+3*m.P[-5]*m.itr_l[i-1,k]**2
        m.F_val_l[i,k] = m.P[-8]+m.P[-7]*m.itr_l[i-1,k]+m.P[-6]*m.itr_l[i-1,k]**2 + m.P[-5]*m.itr_l[i-1,k]**3
        m.itr_l[i,k] = m.itr_l[i-1,k]*((m.F_dash_l[i,k]**2)/(1+m.F_dash_l[i,k]**2))+(st[0]+m.F_dash_l[i,k]*(st[1]-m.F_val_l[i,k]))/(1+m.F_dash_l[i,k]**2)
    m.F_dash_l[0,k] = m.P[-7]+2*m.P[-6]*m.itr_l[p.no_iters-1,k]+3*m.P[-5]*m.itr_l[p.no_iters-1,k]**2
    m.F_val_l[0,k] = m.P[-8]+m.P[-7]*m.itr_l[p.no_iters-1,k]+m.P[-6]*m.itr_l[p.no_iters-1,k]**2 + m.P[-5]*m.itr_l[p.no_iters-1,k]**3
    distance_l =  ((st[0]-m.itr_l[p.no_iters-1,k])**2 + (st[1]-m.F_val_l[0,k])**2)**(1/2)*(2*(st[1]>m.F_val_l[0,k])-1)
    
    m.itr_r[0,k]=st[0]
    for i in range(1,p.no_iters,1):
        m.F_dash_r[i,k] = m.P[-3]+2*m.P[-2]*m.itr_r[i-1,k]+3*m.P[-1]*m.itr_r[i-1,k]**2
        m.F_val_r[i,k] = m.P[-4]+m.P[-3]*m.itr_r[i-1,k]+m.P[-2]*m.itr_r[i-1,k]**2 + m.P[-1]*m.itr_r[i-1,k]**3
        m.itr_r[i,k] = m.itr_r[i-1,k]*((m.F_dash_r[i,k]**2)/(1+m.F_dash_r[i,k]**2))+(st[0]+m.F_dash_r[i,k]*(st[1]-m.F_val_r[i,k]))/(1+m.F_dash_r[i,k]**2)
    m.F_dash_r[0,k] = m.P[-3]+2*m.P[-2]*m.itr_r[p.no_iters-1,k]+3*m.P[-1]*m.itr_r[p.no_iters-1,k]**2
    m.F_val_r[0,k] = m.P[-4]+m.P[-3]*m.itr_r[p.no_iters-1,k]+m.P[-2]*m.itr_r[p.no_iters-1,k]**2 + m.P[-1]*m.itr_r[p.no_iters-1,k]**3
    distance_r =  ((st[0]-m.itr_r[p.no_iters-1,k])**2 + (st[1]-m.F_val_r[0,k])**2)**(1/2)*(2*(st[1]<m.F_val_r[0,k])-1)
    
    m.R[0,0] = (((1+m.F_dash[0,k]**2)**(3/2))/(2*m.P[5]+6*m.P[6]*m.itr[p.no_iters-1,k]))/(((1+m.F_dash[0,k]**2)**(3/2))/(2*m.P[5]+6*m.P[6]*m.itr[p.no_iters-1,k]) + ((st[1]-m.F_val[0,k]-m.F_dash[0,k]*(st[0]-m.itr[p.no_iters-1,k]))>0)*(st[1]-m.F_val[0,k]-m.F_dash[0,k]*(st[0]-m.itr[p.no_iters-1,k]))/(1+m.F_dash[0,k]**2)**(0.5))
    m.g[0,k] =  0 #distance_l
    m.g[1,k] =  0 #distance_r
    m.pen[0,k] = distance_l + p.tolerance
    m.pen[1,k] = distance_r + p.tolerance
    m.obj = m.obj + p.penalty_out_of_road*(m.P[0]<10)*(m.pen[0,k]>0)*m.pen[0,k]**2 # Penalise for going out of left lane
    m.obj = m.obj + p.penalty_out_of_road*(m.P[0]<10)*(m.pen[1,k]>0)*m.pen[1,k]**2 # Penalise for going out of right lane
    Radius = (((1+m.F_dash[0,k]**2)**(3/2))/(2*m.P[5]+6*m.P[6]*m.itr[p.no_iters-1,k]))
    
    dFz = p.lift_coeff*st[3]**2
    dfz = dFz/p.fz0
    muy = (p.pdy1 + p.pdy2*dfz)*p.road_coeff
    

    # Penalty for lateral slip
    lateral_acc_max = muy*p.gravity_constant*(1+dfz)
    lateral_acc_req = (st[3]**2)/Radius
    m.obj = m.obj + p.k_lat_slip*u.sigmoid(10*(lateral_acc_req-lateral_acc_max))*(lateral_acc_max - lateral_acc_req)**2

    for t in range(p.max_no_of_vehicles) : 
        x_v = (m.other_vehicle_x[t,k]-st[0])*cos(atan(m.F_dash[0,k]))+(m.other_vehicle_y[t,k]-st[1])*sin(atan(m.F_dash[0,k]))
        y_v = (m.other_vehicle_y[t,k]-st[1])*cos(atan(m.F_dash[0,k]))-(m.other_vehicle_x[t,k]-st[0])*sin(atan(m.F_dash[0,k]))
        # m.obj = m.obj + blocking_maneuver_cost*(x_v < -vehicle_length_r)*(y_v>0)*(y_v)*((((m.P[9+4*t]-m.X[0,0])**2+(m.P[10+4*t]-m.X[1,0])**2))<100)
        m.obj = m.obj + (m.P[9+4*t]<500)*(p.obs_dist/((m.other_vehicle_x[t,k]-st[0])**2+(m.other_vehicle_y[t,k]-st[1])**2)+0.5) # To maintain safe distance from other vehicles
        m.other_vehicle_t[t,k+1] = m.other_vehicle_t[t,k] + p.T*(m.other_vehicle_v[t,k]/Radius)
        m.other_vehicle_x[t,k+1] = m.other_vehicle_x[t,k] + m.other_vehicle_v[t,k]*cos(m.other_vehicle_t[t,k])*p.T
        m.other_vehicle_y[t,k+1] = m.other_vehicle_y[t,k] + m.other_vehicle_v[t,k]*sin(m.other_vehicle_t[t,k])*p.T
        m.other_vehicle_v[t,k+1] = m.other_vehicle_v[t,k]
    m.obj = m.obj + p.Q_ang*(atan(m.F_dash[0,k])-st[2])**2
    m.obj = m.obj - (1-u.sigmoid(10*(lateral_acc_req-lateral_acc_max)))*p.Q_along*st[3]*cos(atan(m.F_dash[0,k])-st[2])*m.R[0,0] # To move along the lane 
    required_val = Vi + (k+1)*(Vf-Vi)/p.N
    m.obj = m.obj + (st[3]>required_val)*p.k_vel_follow*(required_val-st[3])**2 # Cost for speed difference from optimal racing line speeed
    m.obj = m.obj + p.Q_dist*(m.P[3]+m.P[4]*st[0]+m.P[5]*st[0]*st[0]+m.P[6]*st[0]*st[0]*st[0]-st[1])**2 # Distance from the center lane
    m.obj = m.obj + con.T@m.R1@con # Penalise for more steering angle

for k in range(0,p.N-1,1):
    prev_con=m.U[:,k]
    next_con=m.U[:,k+1]
    m.obj=m.obj+(prev_con- next_con).T@m.R2@(prev_con- next_con)

opt_variables=vertcat(m.U)
OPT_variables = reshape(m.U,2*p.N,1)
g_func = reshape(m.g,2*p.N+4,1)  
nlp_prob = {'f': m.obj, 'x':OPT_variables, 'p': m.P,'g':g_func}
options = {
            'ipopt.print_level' : 0,
            'ipopt.max_iter' : 500,
            'ipopt.mu_init' : 0.01,
            'ipopt.tol' : 1e-8,
            'ipopt.warm_start_init_point' : 'yes',
            'ipopt.warm_start_bound_push' : 1e-9,
            'ipopt.warm_start_bound_frac' : 1e-9,
            'ipopt.warm_start_slack_bound_frac' : 1e-9,
            'ipopt.warm_start_slack_bound_push' : 1e-9,
            'ipopt.mu_strategy' : 'adaptive',
            'print_time' : False,
            'verbose' : False,
            'expand' : True
        }

solver=nlpsol("solver","ipopt",nlp_prob,options)

lbx=np.zeros(2*p.N)
ubx=np.zeros(2*p.N)
lbg=np.zeros(2*(p.N+2))
ubg=np.zeros(2*p.N+4)

for k in range (0,2*p.N,2): 
    lbx[k]=-720*30
    ubx[k]=1
    lbg[k]=-100
    ubg[k] = 100
    #if k>p.N//4:
    #   ubg[k]=0

for k in range (1,(2*p.N),2): 
    lbx[k]=-math.pi
    ubx[k]=math.pi
    lbg[k]=-100
    ubg[k] = 100
    #if k>p.N//4:
    #   ubg[k]=0

lbg[2*p.N] = -100000
lbg[2*p.N+1] = -100000
lbg[2*p.N+2] = -100000
lbg[2*p.N+3] = -100000
ubg[2*p.N] = 100000
ubg[2*p.N+1] = 100000
ubg[2*p.N+2] = 100000
ubg[2*p.N+3] = 100000